Tritos Compress v5 — Linux x86_64
Uso: ./tritos_compress -c [-m mode] in out
     ./tritos_compress -d in.trc5 out
     ./tritos_compress -i file.trc5
